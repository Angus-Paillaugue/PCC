function handleContextMenus(e) {
  switch (e.menuItemId) {
    case "openInPandaBuy":
      chrome.tabs.create({
        url:
          "https://www.pandabuy.com/product?url=" +
          encodeURIComponent(e.linkUrl),
      })
      break
    case "copyProductLink":
      chrome.tabs.query({ active: !0, currentWindow: !0 }, function (e) {
        e = e[0]
        chrome.tabs.sendMessage(e.id, {
          message: "copyToClipboard",
          data: new URL(e.url).searchParams.get("url"),
        })
      })
      break
    default:
      console.log("Unknown context-menu clicked :", e.menuItemId)
  }
}
chrome.contextMenus.onClicked.addListener(handleContextMenus),
  chrome.runtime.onInstalled.addListener(function () {
    console.log("Service worker installed."),
      chrome.storage.local.get(["username", "password"], (e) => {
        var { username: e, password: o } = e
        console.log("Checking if user is logged-in..."),
          o
            ? (console.log("User is logged-in, checking if user is premium..."),
              fetch("https://pcc.paillaugue.fr/checkPremium", {
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username: e, password: o }),
                method: "POST",
              })
                .then((e) => e.json())
                .then((e) => {
                  console.log(
                    e.isPremium ? "User is premium" : "User is not premium",
                  ),
                    chrome.storage.local.set({ isPremium: e.isPremium })
                })
                .catch((e) => {
                  console.error("Error making the request:", e)
                }))
            : (console.log("User is not logged-in"),
              chrome.storage.local.set({ isPremium: !1 }))
      }),
      chrome.contextMenus.create({
        title: "Open in PandaBuy",
        contexts: ["link"],
        id: "openInPandaBuy",
        targetUrlPatterns: [
          "*://*.yupoo.com/*?*id=*",
          "*://*.yupoo.com/*?*itemID=*",
          "*://m.weidian.com/*?*id=*",
          "*://m.weidian.com/*?*itemID=*",
          "*://weidian.com/*?*id=*",
          "*://weidian.com/*?*itemID=*",
          "*://*.taobao.com/*?*id=*",
          "*://*.taobao.com/*?*itemID=*",
          "*://*.1688.com/*?*id=*",
          "*://*.1688.com/*?*itemID=*",
          "*://*.tmall.com/*?*id=*",
          "*://*.tmall.com/*?*itemID=*",
        ],
      }),
      chrome.contextMenus.create({
        title: "Copy product link",
        contexts: ["page"],
        id: "copyProductLink",
        documentUrlPatterns: ["*://*.pandabuy.com/product?*"],
      })
  }),
  chrome.runtime.onMessage.addListener((o, e, t) => {
    "updateTabURL" === o.type &&
      chrome.tabs.query({ active: !0, currentWindow: !0 }, ([e]) => {
        chrome.tabs.update(e.id, { url: o.url })
      })
  })
