const marketplacesUrls = [
    "*://*.pandabuy.com/*",
    "*://*.sugargoo.com/*",
    "*://*.yupoo.com/*",
    "*://*.weidian.com/*",
    "*://weidian.com/*",
    "*://*.taobao.com/*",
    "*://*.1688.com/*",
    "*://*.tmall.com/*",
  ],
  urlMatch = (e, t = location.origin) => {
    try {
      for (const o of e) if (new URLPattern(o).test(t)) return !0;
      return !1;
    } catch (e) {
      return !1;
    }
  };
function isMarketplaceUrl() {
  return urlMatch(marketplacesUrls);
}
function getProductId(e) {
  if (isMarketplaceUrl(e))
    if (urlMatch(["*://*.pandabuy.com/*"], e)) {
      if ("itemID" == new URL(e)?.searchParams?.get("itemID"))
        return new URL(e).searchParams.get(searchParam);
    } else {
      var t = ["id", "itemID"];
      for (const searchParam of new URL(e)?.searchParams?.keys())
        if (t.includes(searchParam))
          return new URL(e).searchParams.get(searchParam);
      if (new URLPattern({ pathname: "/offer/*.html" }).test(location.href))
        return location.href.match(/[0-9]{12}/g)[0];
      if (urlMatch(["*://*.cssbuy.com//item-*.html"], location.href))
        return e.match(/item-[0-9]{12}/g)[0].replace("item-", "");
    }
  return !1;
}
function isAProductPage(e) {
  return !!getProductId(e);
}
function copyToClipboard(e) {
  var t = document.createElement("textarea");
  (t.style.opacity = 0),
    (t.style.width = 0),
    (t.style.height = 0),
    (t.style.position = "absolute"),
    (t.style.bottom = "-100%"),
    (t.style.left = "-100%"),
    (t.style.margin = 0),
    (t.value = e),
    document.body.appendChild(t),
    t.select(),
    document.execCommand("copy"),
    t.remove(),
    $("#likCopiedToast").remove(),
    chrome.storage.local.get(["darkMode"], (e) => {
      (e = e?.darkMode ?? !1),
        $("body").append(`
        <div id="likCopiedToast" style="margin: 0; opacity: 0; display: flex; position: fixed; top: 0.5rem; right: 0.5rem; padding: 1rem; align-items: center; gap: .5rem; border-radius: 0.5rem; width: 100%; max-width: 20rem; color: rgb(${
          e ? "21 128 61" : "22 163 74"
        }) !important; background-color: #${
          e ? "1f2937" : "FFFFFF"
        } !important; box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06); z-index: 9999;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" id="linkCopiedToastSvg" style="width: 20px;height: 20px;">
                <path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clip-rule="evenodd" />
            </svg>
            <p style="font-size: 1rem;font-weight: 400; margin: 0;">Link copied successfully!</p>
        </div>
        `),
        $("#likCopiedToast").animate({ opacity: "1" }, 150, function () {
          setTimeout(function () {
            $("#likCopiedToast").animate({ opacity: "0" }, 150, function () {
              $("#likCopiedToast").remove();
            });
          }, 3e3);
        });
    });
}
function fetchLive(t, o) {
  fetch("https://api.exchangerate-api.com/v4/latest/" + t)
    .then((e) => e.json())
    .then((e) => {
      chrome.storage.local.set(
        {
          cache: { currencyToConvertTo: t, data: e.rates },
          cacheTime: Date.now(),
        },
        () => {
          o(e.rates);
        }
      );
    });
}
function getRates(t, o) {
  chrome.storage.local.get(["cache", "cacheTime"], (e) => {
    if (
      e?.cache &&
      e?.cacheTime > Date.now() - 36e5 &&
      e?.cache?.currencyToConvertTo === t
    )
      return (
        console.log(`PCC : Using cached ${t} conversion rates`), o(e.cache.data)
      );
    console.log(`PCC : Fetching live ${t} exchange rates from api`),
      fetchLive(t, o);
  });
}
function formatString(e, t, o, r) {
  if (
    ((e = e.replaceAll("￥", "¥")),
    urlMatch(["*://*.pandabuy.com"]) &&
      ("/cartEstimatedFreight" === location.pathname ||
        "/person/parcel/list" === location.pathname))
  )
    for (const d of o) e = e.replaceAll(d.name, d.symbol);
  var a = [
    ...e.matchAll(
      /([$€¥£₹₽₴₱₪₨₩₦₢₣₥₫₵]\s?\.?~?\s?\d+(\.\d{1,2})?|\d+(\.\d{1,2})?\s?\.?~?\s?[$€¥£₹₽₴₱₪₨₩₦₢₣₥₫₵])/g
    ),
  ];
  if (0 === a.length) return e;
  let c = "",
    n = 0;
  for (const u of a) {
    const m = u[0].match(/[$€¥£₹₽₴₱₪₨₩₦₢₣₥₫₵]/g)[0];
    var l,
      i,
      s = parseFloat(u[0].match(/[-+]?\d+(\.\d+)?/g)[0]);
    m &&
      s &&
      (l = o.filter((e) => e.symbol === m)[0]).name !== r &&
      ((i = t[l.name]),
      (s = isNaN(s) ? "" : (parseFloat(s) / i).toFixed(2)),
      (c = (c +=
        e.substring(n, u.index - 1) +
        s +
        " " +
        o.filter((e) => e.name === r)[0].symbol).replaceAll(l.name, "")),
      (n = u.index + u[0].length));
  }
  return (c += e.substring(n));
}
function conversion() {
  chrome.storage.local.get(["convertTo"], (c) => {
    getRates((c = c?.convertTo ?? "USD"), (a) => {
      const t = new XMLHttpRequest();
      t.open("GET", chrome.runtime.getURL("currencies.json")),
        (t.onreadystatechange = function () {
          if (4 == this.readyState && 200 === this.status) {
            const r = JSON.parse(t.responseText);
            var e = document.querySelector("title");
            e && (e.innerText = formatString(e.innerText, a, r, c)),
              setInterval(() => {
                document
                  .querySelectorAll(
                    "span, p, a, h1, h2, h3, h4, h5, h6, em, tr, ul, ol, tr, label, div, dd, li"
                  )
                  .forEach((t) => {
                    for (let e = 0; e < t.childNodes.length; ++e) {
                      var o;
                      t.childNodes[e].nodeType === Node.TEXT_NODE &&
                        (o = formatString(
                          t.childNodes[e].textContent,
                          a,
                          r,
                          c
                        )) !== t.childNodes[e].textContent &&
                        (t.childNodes[e].textContent = o);
                    }
                  });
              }, 1e3);
          }
        }),
        t.send();
    });
  });
}
function changeYupooGrid() {
  urlMatch(["*://*.yupoo.com/*"]) &&
    chrome.storage.local.get(["yupooInterfaceReDesign"], (e) => {
      (e?.yupooInterfaceReDesign ?? !1) &&
        chrome.storage.local.get(["yupooContentWidth"], (e) => {
          const o = e?.yupooContentWidth ?? 170;
          document.querySelector(".showalbumheader__main") &&
            (document.querySelector(".showalbumheader__main").style.maxWidth =
              "100%"),
            document.querySelector(".showindex__gallerycardwrap") &&
              (document.querySelector(
                ".showindex__gallerycardwrap"
              ).style.maxWidth = "100%"),
            document.querySelector(".showalbum__imagecardwrap") &&
              (document.querySelector(
                ".showalbum__imagecardwrap"
              ).style.maxWidth = "100%"),
            document.querySelector(".categories__box.clearfix") &&
              (document.querySelector(
                ".categories__box.clearfix"
              ).style.maxWidth = "100%");
          let r = 0;
          const a = setInterval(() => {
            var e = document.querySelectorAll(
              ".categories__parent.album__categories-box, .showalbum__parent, .showindex__parent, .showalbum__parent, .showindex__parent"
            );
            (0 < e.length || 10 === r) && clearInterval(a);
            for (const t of e)
              console.log(t),
                (t.style.display = "grid"),
                (t.style.gap = "10px"),
                (t.style.gridTemplateColumns = `repeat(auto-fill, minmax(${o}px, 1fr))`),
                Array.from(t.children).forEach((e) => {
                  (e.style.width = "100%"), (e.style.margin = "0");
                });
            r++;
          }, 200);
        });
    });
}
function toggleYupooSideBar() {
  urlMatch(["*://*.yupoo.com/*"]) &&
    chrome.storage.local.get(["removeYupooSideBar"], (e) => {
      (e = e?.removeYupooSideBar ?? !0)
        ? chrome.storage.local.get(["yupooInterfaceReDesign"], (e) => {
            (e?.yupooInterfaceReDesign ?? !1) &&
              (document.querySelector(".yupoo-categories-hide-sidebar") &&
                (document.querySelector(
                  ".yupoo-categories-hide-sidebar"
                ).style.display = "none"),
              document.querySelector(".categories__box-left") &&
                (document.querySelector(".categories__box-left").style.display =
                  "none"),
              document.querySelector(".categories__box-right")) &&
              (document.querySelector(
                ".categories__box-right"
              ).style.marginLeft = "0");
          })
        : (document.querySelector(".yupoo-categories-hide-sidebar") &&
            (document.querySelector(
              ".yupoo-categories-hide-sidebar"
            ).style.display = "block"),
          document.querySelector(".categories__box-left") &&
            (document.querySelector(".categories__box-left").style.display =
              "block"),
          document.querySelector(".categories__box-right") &&
            (document.querySelector(".categories__box-right").style.marginLeft =
              "216px"));
    });
}
function productWarnings() {
  chrome.storage.local.get(["pandabuyProductWarnings"], (e) => {
    if ((e = e?.pandabuyProductWarnings ?? !1)) {
      let e = 0;
      const t = setInterval(() => {
        if (
          (20 === e && clearInterval(t),
          document.querySelector(".el-button.accept-btn.el-button--default"))
        )
          try {
            document
              .querySelector(".el-button.accept-btn.el-button--default")
              .click(),
              clearInterval(t);
          } catch (e) {}
        e++;
      }, 200);
    }
  });
}
function customProductQC() {
  urlMatch(["*://*.pandabuy.com/product?*"], location.href) &&
    chrome.storage.local.get(["customProductQC"], (o) => {
      if ((o = o?.customProductQC ?? !1)) {
        o = new URL(location.href).searchParams.get("url");
        let e = new URL(o).origin.split(".").at(-2).split("/").at(-1);
        const r = (e =
            "tmall" ===
            (e = "1688" === (e = "weidian" === e ? "wd" : e) ? "alibaba" : e)
              ? "taobao"
              : e),
          a = getProductId(o);
        let t = 0;
        const c = setInterval(() => {
          t += 1;
          try {
            if ((20 <= t && clearInterval(c), 0 === $(".overview").length))
              throw new Error("I got nowhere to append the QC's!");
            clearInterval(c),
              $(".overview").after(
                `<div style="padding:20px; width:100%;" class="customProductQCContainer"><h2 class="margin-bottom:5px;">Product QC : </h2><iframe src="https://www.pandabuy.com/storageQcImg?itemId=${a}&providerType=${r}&activeIndex=0&type=imageList" style="width:100%; aspect-ratio:16/9; border:none;" id="QCIframe"></iframe></div>`
              );
            var e = (
              document.getElementById("QCIframe").contentDocument ||
              document.getElementById("QCIframe").contentWindow.document
            ).getElementById("big-img-layout");
            (e.style.maxWidth = "unset"),
              (e.style.width = "calc(100vw - 145px)"),
              (e.style.margin = "0 0 0 10px");
          } catch (e) {}
        }, 1e3);
      }
    });
}
function setDarkMode() {
  chrome.storage.local.get(["darkMode"], (e) => {
    (e = e?.darkMode ?? !1) &&
    urlMatch(["*://*.pandabuy.com/*", "*://*.yupoo.com/*"])
      ? (((e = document.createElement("link")).href = chrome.runtime.getURL(
          "/src/dark-theme.css"
        )),
        (e.type = "text/css"),
        (e.rel = "stylesheet"),
        (e.id = "PCCDarkTheme"),
        document.head.appendChild(e))
      : document.getElementById("PCCDarkTheme") &&
        document
          .getElementById("PCCDarkTheme")
          .parentNode.removeChild(document.getElementById("PCCDarkTheme"));
  });
}
function track() {
  if (urlMatch(["*://*.pandabuy.com/person/parcel/list"], location.href)) {
    if (!document.querySelector(".parcel-num")) return setTimeout(track, 1e3);
    for (const o of document.querySelectorAll(
      "div.item.vertical-style.line > p:nth-child(3)"
    )) {
      var e = o.innerText.trim(),
        t = document.createElement("a");
      (t.href = "https://www.17track.net/en/track?nums=" + e),
        (t.target = "_blank"),
        (t.innerText = "Track on 17Track"),
        o.parentNode.appendChild(t);
    }
  }
}
function callPremium() {
  changeYupooGrid(),
    toggleYupooSideBar(),
    productWarnings(),
    customProductQC(),
    setDarkMode(),
    chrome.storage.local.get(["thirdPartyDisclaimerAutoCheck"], (e) => {
      if (
        (e = e?.thirdPartyDisclaimerAutoCheck ?? !1) &&
        urlMatch(["*://*.pandabuy.com/product?*"], location.href)
      ) {
        const t = () => {
          try {
            (document.querySelector("input.el-checkbox__original").checked =
              !1),
              document
                .querySelector(".el-checkbox")
                .classList.add("is-checked");
          } catch (e) {
            setTimeout(() => {
              t();
            }, 1e3);
          }
        };
        t();
      }
    }),
    chrome.storage.local.get(["skipYupooRedirect"], (e) => {
      (e = e?.skipYupooRedirect ?? !1) &&
        urlMatch(["https://x.yupoo.com/external?url=*"], location.href) &&
        chrome.runtime.sendMessage({
          type: "updateTabURL",
          url: decodeURIComponent(
            new URL(location.href).searchParams.get("url")
          ),
        });
    }),
    chrome.storage.local.get(["autoPandaBuyRedirect"], (e) => {
      (e = e?.autoPandaBuyRedirect ?? !1) &&
        isAProductPage(location.href) &&
        chrome.runtime.sendMessage({
          type: "updateTabURL",
          url:
            "https://www.pandabuy.com/product?url=" +
            encodeURIComponent(location.href),
        });
    }),
    chrome.runtime.onMessage.addListener((e) => {
      "toggledSideBar" === e && toggleYupooSideBar(),
        "productWarningsChange" === e && productWarnings(),
        "yupooContentWidthChanged" === e && changeYupooGrid(),
        "darkModeToggled" === e && setDarkMode(),
        "copyToClipboard" === e?.message && copyToClipboard(e.data);
    });
}
chrome.storage.local.get(["status"], (e) => {
  (e = e?.status ?? !0) &&
    (isMarketplaceUrl() ||
      new URLPattern("*://*.reddit.com/*").test(
        new URL(location.href).origin
      )) &&
    chrome.storage.local.get(["username", "password"], (e) => {
      var { username: e, password: t } = e;
      e && t && conversion();
    });
}),
  chrome.storage.local.get(["isPremium"], (e) => {
    (e = e?.isPremium ?? !1) && callPremium();
  }),
  track();
