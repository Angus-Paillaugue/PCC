function sendMessage(t) {
  chrome.tabs.query({ currentWindow: !0, active: !0 }, function (e) {
    chrome.tabs.sendMessage(e[0].id, t)
  })
}
const reloadTab = (o = ["*://*/*"], c = "origin", e) => {
  e
    ? chrome.tabs.reload(tab)
    : chrome.tabs.query({ active: !0, lastFocusedWindow: !0 }, ([e]) => {
        for (const t of o)
          new URLPattern(t).test(new URL(e.url)[c]) && chrome.tabs.reload(e.id)
      })
}
function main() {
  const t = document.getElementById("conversionChildren")
  chrome.storage.local.get(["status"], (e) => {
    ;(e = e?.status ?? !0),
      (document.getElementById("status").checked = e),
      (t.style.maxHeight = e ? t.scrollHeight + "px" : "0px")
  }),
    setCheckBoxes(),
    document
      .getElementById("autoPandaBuyRedirect")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ autoPandaBuyRedirect: e }),
          reloadTab([
            "*://m.weidian.com/*",
            "*://weidian.com/*",
            "*://*.taobao.com/*",
            "*://*.1688.com/*",
            "*://*.tmall.com/*",
          ])
      }),
    document
      .getElementById("pandabuyProductWarnings")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ pandabuyProductWarnings: e }),
          sendMessage("productWarningsChange")
      }),
    document
      .getElementById("thirdPartyDisclaimerAutoCheck")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ thirdPartyDisclaimerAutoCheck: e }),
          reloadTab(["*://*.pandabuy.com/product?*"], "href")
      }),
    document
      .getElementById("customProductQC")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ customProductQC: e }),
          reloadTab(["*://*.pandabuy.com/product?*"], "href")
      }),
    document
      .getElementById("yupooInterfaceReDesign")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ yupooInterfaceReDesign: e }),
          reloadTab(["*://*.yupoo.com/*"]),
          (document.getElementById(
            "yupooInterfaceReDesignChildren",
          ).style.maxHeight =
            (e
              ? document.getElementById("yupooInterfaceReDesignChildren")
                  .scrollHeight
              : 0) + "px")
      }),
    document
      .getElementById("removeYupooSideBar")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ removeYupooSideBar: e }),
          sendMessage("toggledSideBar")
      }),
    document
      .getElementById("skipYupooRedirect")
      .addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ skipYupooRedirect: e })
      })
  const o = document.getElementById("darkMode")
  o.addEventListener("change", (e) => {
    e = e.currentTarget.checked
    chrome.storage.local.set({ darkMode: e }), sendMessage("darkModeToggled")
  }),
    chrome.storage.local.get(["darkMode"], (e) => {
      ;(e = e?.darkMode ?? !1), (o.checked = e)
    })
}
function setCheckBoxes() {
  const t = document.getElementById("autoPandaBuyRedirect"),
    o =
      (chrome.storage.local.get(["autoPandaBuyRedirect"], (e) => {
        ;(e = e?.autoPandaBuyRedirect ?? !1), (t.checked = e)
      }),
      document.getElementById("thirdPartyDisclaimerAutoCheck")),
    c =
      (chrome.storage.local.get(["thirdPartyDisclaimerAutoCheck"], (e) => {
        ;(e = e?.thirdPartyDisclaimerAutoCheck ?? !1), (o.checked = e)
      }),
      document.getElementById("pandabuyProductWarnings")),
    n =
      (chrome.storage.local.get(["pandabuyProductWarnings"], (e) => {
        ;(e = e?.pandabuyProductWarnings ?? !1), (c.checked = e)
      }),
      document.getElementById("customProductQC")),
    a =
      (chrome.storage.local.get(["customProductQC"], (e) => {
        ;(e = e?.customProductQC ?? !1), (n.checked = e)
      }),
      document.getElementById("yupooInterfaceReDesign")),
    r =
      (chrome.storage.local.get(["yupooInterfaceReDesign"], (e) => {
        ;(e = e?.yupooInterfaceReDesign ?? !1),
          (a.checked = e),
          (document.getElementById(
            "yupooInterfaceReDesignChildren",
          ).style.maxHeight =
            (e
              ? document.getElementById("yupooInterfaceReDesignChildren")
                  .scrollHeight
              : 0) + "px")
      }),
      document.getElementById("removeYupooSideBar")),
    d =
      (chrome.storage.local.get(["removeYupooSideBar"], (e) => {
        ;(e = e?.removeYupooSideBar ?? !1), (r.checked = e)
      }),
      document.getElementById("skipYupooRedirect"))
  chrome.storage.local.get(["skipYupooRedirect"], (e) => {
    ;(e = e?.skipYupooRedirect ?? !1), (d.checked = e)
  }),
    chrome.storage.local.get(["yupooContentWidth"], (e) => {
      var t = document.getElementById("yupooContentWidthSlider")
      const o = document.getElementById("yupooContentWidth")
      ;(yupooContentWidth = e?.yupooContentWidth ?? 180),
        (t.value = yupooContentWidth),
        (o.innerHTML = yupooContentWidth),
        (t.oninput = function () {
          var e = this.value
          ;(o.innerHTML = e),
            chrome.storage.local.set({ yupooContentWidth: e }),
            sendMessage("yupooContentWidthChanged")
        })
    })
}
function setPopupTheme() {
  const t = document.getElementById("popupTheme")
  t.addEventListener("change", (e) => {
    e = e.currentTarget.checked
    chrome.storage.local.set({ popupDarkTheme: e }), setPopupTheme()
  }),
    chrome.storage.local.get(["popupDarkTheme"], (e) => {
      ;(e = e?.popupDarkTheme ?? !1),
        (t.checked = e)
          ? document.documentElement.classList.add("dark")
          : document.documentElement.classList.remove("dark")
    })
}
function setUpdateBanner() {
  const t = chrome.runtime.getManifest().version,
    o = chrome.runtime.getManifest().update_notes,
    c = document.getElementById("updateBanner")
  chrome.storage.local.get(["extensionVersion"], (e) => {
    ;(e = e?.extensionVersion ?? "0.0.0") !== t &&
      ((c.querySelector(
        "p",
      ).innerHTML = `<span class="text-base"><span class="font-bold">New update v${t}</span> : ${o}</span>`),
      c.classList.remove("-mt-12"),
      c.querySelector("button").addEventListener("click", () => {
        console.log("click"),
          chrome.storage.local.set({ extensionVersion: t }),
          c.classList.add("-mt-12")
      }))
  })
}
document.addEventListener("DOMContentLoaded", () => {
  main(), setPopupTheme(), setUpdateBanner()
  const t = document.getElementById("status"),
    o = document.getElementById("conversionChildren"),
    n =
      (t.addEventListener("change", (e) => {
        e = e.currentTarget.checked
        chrome.storage.local.set({ status: e }),
          reloadTab([
            "*://*.pandabuy.com/*",
            "*://*.yupoo.com/*",
            "*://*.weidian.com/*",
            "*://weidian.com/*",
            "*://*.taobao.com/*",
            "*://*.1688.com/*",
            "*://*.tmall.com/*",
          ]),
          (o.style.maxHeight = e ? o.scrollHeight + "px" : "0px")
      }),
      chrome.storage.local.get(["status"], (e) => {
        ;(e = e?.status ?? !0),
          (t.checked = e),
          (o.style.maxHeight = e ? o.scrollHeight + "px" : "0px")
      }),
      new XMLHttpRequest())
  n.open("GET", chrome.runtime.getURL("currencies.json")),
    (n.onreadystatechange = function () {
      if (4 == this.readyState && 200 === this.status) {
        const e = JSON.parse(n.responseText),
          c = document.getElementById("convertTo")
        chrome.storage.local.get(["convertTo"], (o) => {
          e.forEach((e) => {
            var t = document.createElement("option")
            ;(t.value = e.name),
              (t.text = e.name + " - " + e.symbol),
              c.appendChild(t),
              (o?.convertTo !== e.name && (o?.convertTo || "USD" !== e.name)) ||
                (t.selected = "selected")
          })
        }),
          c.addEventListener("change", () => {
            chrome.storage.local.set({ convertTo: c.value }), reloadTab()
          })
      }
    }),
    n.send()
  for (const e of document.querySelectorAll("a"))
    e.addEventListener("click", (e) => {
      chrome.tabs.create({ url: e.target.getAttribute("href") })
    })
  let c = []
  document.addEventListener("keydown", (e) => {
    c.push(e.key),
      c.forEach((e, t) => {
        switch (t) {
          case 0:
          case 1:
            "ArrowUp" !== e && (c = [])
            break
          case 2:
          case 3:
            "ArrowDown" !== e && (c = [])
            break
          case 4:
          case 6:
            "ArrowLeft" !== e && (c = [])
            break
          case 5:
          case 7:
            "ArrowRight" !== e && (c = [])
            break
          case 8:
            "b" !== e && (c = [])
            break
          case 9:
            "a" !== e && (c = [])
        }
        9 == t &&
          10 == c.length &&
          ((c = []),
          chrome.storage.local.get(["popupDarkTheme"], (e) => {
            e = e?.popupDarkTheme ?? !1
            e = document.createElement("div")
            ;(e.classList =
              "fixed bg-neutral-500 dark:bg-neutral-400 bg-opacity-75 h-screen z-50 w-full h-full top-0 left-0 flex flex-col justify-content-center items-center"),
              (e.innerHTML =
                '<img src="/src/Screamer.webp" class="h-full w-auto">'),
              (e.id = "screamer"),
              document.body.appendChild(e),
              setTimeout(() => {
                document.getElementById("screamer") &&
                  document.getElementById("screamer").remove()
              }, 1500)
          }))
      })
  })
})
