function sendMessage(t) {
  chrome.tabs.query({ currentWindow: !0, active: !0 }, function (e) {
    chrome.tabs.sendMessage(e[0].id, t);
  });
}
const reloadTab = (o = ["*://*/*"], n = "origin", e) => {
  e
    ? chrome.tabs.reload(tab)
    : chrome.tabs.query({ active: !0, lastFocusedWindow: !0 }, ([e]) => {
        for (const t of o)
          new URLPattern(t).test(new URL(e.url)[n]) && chrome.tabs.reload(e.id);
      });
};
function main() {
  chrome.storage.local.get(["username", "password"], (e) => {
    var { username: e, password: t } = e;
    const a = document.getElementById("err"),
      r = document.getElementById("errMsg");
    e && t
      ? chrome.storage.local.get(["isPremium"], (e) => {
          e = e?.isPremium ?? !1;
          setGrayedBackground(),
            document.getElementById("unlockFeaturesParagraph") &&
              document.getElementById("unlockFeaturesParagraph").remove(),
            document.getElementById("auth") &&
              (document.getElementById("auth").style.display = "none"),
            document.getElementById("main") &&
              (document.getElementById("main").style.display = "block"),
            (document.getElementById("plan").innerText = e
              ? "Premium"
              : "Basic");
          const t = document.getElementById("conversionChildren");
          if (
            (chrome.storage.local.get(["status"], (e) => {
              (e = e?.status ?? !0),
                (document.getElementById("status").checked = e),
                (t.style.maxHeight = e ? t.scrollHeight + "px" : "0px");
            }),
            e)
          ) {
            document.getElementById("hide") &&
              document.getElementById("hide").remove(),
              setCheckBoxes(),
              document
                .getElementById("autoPandaBuyRedirect")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({ autoPandaBuyRedirect: e }),
                    reloadTab([
                      "*://m.weidian.com/*",
                      "*://weidian.com/*",
                      "*://*.taobao.com/*",
                      "*://*.1688.com/*",
                      "*://*.tmall.com/*",
                    ]);
                }),
              document
                .getElementById("pandabuyProductWarnings")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({ pandabuyProductWarnings: e }),
                    sendMessage("productWarningsChange");
                }),
              document
                .getElementById("thirdPartyDisclaimerAutoCheck")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({
                    thirdPartyDisclaimerAutoCheck: e,
                  }),
                    reloadTab(["*://*.pandabuy.com/product?*"], "href");
                }),
              document
                .getElementById("customProductQC")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({ customProductQC: e }),
                    reloadTab(["*://*.pandabuy.com/product?*"], "href");
                }),
              document
                .getElementById("yupooInterfaceReDesign")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({ yupooInterfaceReDesign: e }),
                    reloadTab(["*://*.yupoo.com/*"]),
                    (document.getElementById(
                      "yupooInterfaceReDesignChildren"
                    ).style.maxHeight =
                      (e
                        ? document.getElementById(
                            "yupooInterfaceReDesignChildren"
                          ).scrollHeight
                        : 0) + "px");
                }),
              document
                .getElementById("removeYupooSideBar")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({ removeYupooSideBar: e }),
                    sendMessage("toggledSideBar");
                }),
              document
                .getElementById("skipYupooRedirect")
                .addEventListener("change", (e) => {
                  e = e.currentTarget.checked;
                  chrome.storage.local.set({ skipYupooRedirect: e });
                });
            const o = document.getElementById("darkMode");
            o.addEventListener("change", (e) => {
              e = e.currentTarget.checked;
              chrome.storage.local.set({ darkMode: e }),
                sendMessage("darkModeToggled");
            }),
              chrome.storage.local.get(["darkMode"], (e) => {
                (e = e?.darkMode ?? !1), (o.checked = e);
              });
          }
        })
      : (document.getElementById("main") &&
          (document.getElementById("main").style.display = "none"),
        document.getElementById("auth") &&
          (document.getElementById("auth").style.display = "block"),
        document.getElementById("log-in").addEventListener("submit", (e) => {
          e.preventDefault();
          const t = e.submitter,
            o =
              ((t.innerHTML = `<svg fill='none' class="w-6 h-6 animate-spin mx-auto" viewBox="0 0 32 32" xmlns='http://www.w3.org/2000/svg'><path clip-rule='evenodd' d='M15.165 8.53a.5.5 0 01-.404.58A7 7 0 1023 16a.5.5 0 011 0 8 8 0 11-9.416-7.874.5.5 0 01.58.404z' fill='currentColor' fill-rule='evenodd' /></svg>`),
              document.getElementById("username").value),
            n = document.getElementById("password").value;
          fetch("https://pcc.paillaugue.fr/checkPremium", {
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username: o, password: n }),
            method: "POST",
          })
            .then((e) => e.json())
            .then((e) => {
              e?.err
                ? ((a.style.display = "flex"), (r.innerText = e.err))
                : ((a.style.display = "none"),
                  chrome.storage.local.set({ isPremium: e.isPremium }),
                  chrome.storage.local.set({ username: o }),
                  chrome.storage.local.set({ password: n }),
                  document.getElementById("main") &&
                    (document.getElementById("main").style.display = "block"),
                  document.getElementById("auth") &&
                    (document.getElementById("auth").style.display = "none"),
                  main());
            })
            .catch((e) => {
              console.log(e), (a.style.display = "flex"), (r.innerText = e);
            })
            .finally(() => {
              t.innerText = "Log in";
            });
        }));
  });
}
function setCheckBoxes() {
  chrome.storage.local.get(["isPremium"], (e) => {
    const t = e?.isPremium ?? !1,
      o = document.getElementById("autoPandaBuyRedirect"),
      n =
        (chrome.storage.local.get(["autoPandaBuyRedirect"], (e) => {
          (e = !!t && (e?.autoPandaBuyRedirect ?? !1)), (o.checked = e);
        }),
        document.getElementById("thirdPartyDisclaimerAutoCheck")),
      a =
        (chrome.storage.local.get(["thirdPartyDisclaimerAutoCheck"], (e) => {
          (e = !!t && (e?.thirdPartyDisclaimerAutoCheck ?? !1)),
            (n.checked = e);
        }),
        document.getElementById("pandabuyProductWarnings")),
      r =
        (chrome.storage.local.get(["pandabuyProductWarnings"], (e) => {
          (e = !!t && (e?.pandabuyProductWarnings ?? !1)), (a.checked = e);
        }),
        document.getElementById("customProductQC")),
      c =
        (chrome.storage.local.get(["customProductQC"], (e) => {
          (e = e?.customProductQC ?? !1), (r.checked = e);
        }),
        document.getElementById("yupooInterfaceReDesign")),
      d =
        (chrome.storage.local.get(["yupooInterfaceReDesign"], (e) => {
          (e = !!t && (e?.yupooInterfaceReDesign ?? !1)),
            (c.checked = e),
            (document.getElementById(
              "yupooInterfaceReDesignChildren"
            ).style.maxHeight =
              (e
                ? document.getElementById("yupooInterfaceReDesignChildren")
                    .scrollHeight
                : 0) + "px");
        }),
        document.getElementById("removeYupooSideBar")),
      s =
        (chrome.storage.local.get(["removeYupooSideBar"], (e) => {
          (e = !!t && (e?.removeYupooSideBar ?? !1)), (d.checked = e);
        }),
        document.getElementById("skipYupooRedirect"));
    chrome.storage.local.get(["skipYupooRedirect"], (e) => {
      (e = !!t && (e?.skipYupooRedirect ?? !1)), (s.checked = e);
    }),
      chrome.storage.local.get(["yupooContentWidth"], (e) => {
        var t = document.getElementById("yupooContentWidthSlider");
        const o = document.getElementById("yupooContentWidth");
        (yupooContentWidth = e?.yupooContentWidth ?? 180),
          (t.value = yupooContentWidth),
          (o.innerHTML = yupooContentWidth),
          (t.oninput = function () {
            var e = this.value;
            (o.innerHTML = e),
              chrome.storage.local.set({ yupooContentWidth: e }),
              sendMessage("yupooContentWidthChanged");
          });
      });
  });
}
function setGrayedBackground() {
  document.getElementById("unlockFeaturesParagraph") &&
    document.getElementById("unlockFeaturesParagraph").remove();
  const a = document.getElementById("main").querySelectorAll("section");
  chrome.storage.local.get(["isPremium"], (e) => {
    if ((e = e?.isPremium ?? !1)) for (const o of a) o.style.display = "flex";
    else {
      var e = document.createElement("p"),
        t =
          ((e.id = "unlockFeaturesParagraph"),
          (e.className =
            "text-base font-bold px-4 py-2 block text-center border-t border-neutral-200 dark:border-neutral-700"),
          (e.innerHTML = "To unlock all the features, "),
          document.createElement("a"));
      (t.href = "https://pcc.paillaugue.fr/pricing"),
        (t.innerText = "Upgrade to premium"),
        t.addEventListener("click", (e) => {
          chrome.tabs.create({ url: e.target.getAttribute("href") });
        }),
        e.appendChild(t),
        document.querySelector("#main > section:nth-child(1)").appendChild(e);
      for (const n in a)
        0 < n && n < a.length - 1 && (a[n].style.display = "none");
    }
  });
}
function setPopupTheme() {
  const t = document.getElementById("popupTheme");
  t.addEventListener("change", (e) => {
    e = e.currentTarget.checked;
    chrome.storage.local.set({ popupDarkTheme: e }), setPopupTheme();
  }),
    chrome.storage.local.get(["popupDarkTheme"], (e) => {
      (e = e?.popupDarkTheme ?? !1),
        (t.checked = e)
          ? document.documentElement.classList.add("dark")
          : document.documentElement.classList.remove("dark");
    });
}
function refreshPlan(e) {
  const o = e.target;
  (o.innerHTML = `<svg fill='none' class="w-6 h-6 animate-spin mx-auto" viewBox="0 0 32 32" xmlns='http://www.w3.org/2000/svg'><path clip-rule='evenodd' d='M15.165 8.53a.5.5 0 01-.404.58A7 7 0 1023 16a.5.5 0 011 0 8 8 0 11-9.416-7.874.5.5 0 01.58.404z' fill='currentColor' fill-rule='evenodd' /></svg>`),
    chrome.storage.local.get(["username", "password"], (e) => {
      var { username: e, password: t } = e;
      fetch("https://pcc.paillaugue.fr/checkPremium", {
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: e, password: t }),
        method: "POST",
      })
        .then((e) => e.json())
        .then((e) => {
          chrome.storage.local.set({ isPremium: e.isPremium }),
            main(),
            (o.innerText = "Refresh plan");
        });
    });
}
document.addEventListener("DOMContentLoaded", () => {
  main(),
    setPopupTheme(),
    document.getElementById("log-out").addEventListener("click", () => {
      chrome.storage.local.set({ username: null }),
        chrome.storage.local.set({ password: null }),
        chrome.storage.local.set({ isPremium: null }),
        main();
    }),
    document.getElementById("refreshPlan").addEventListener("click", (e) => {
      refreshPlan(e);
    });
  const t = document.getElementById("status"),
    o = document.getElementById("conversionChildren"),
    a =
      (t.addEventListener("change", (e) => {
        e = e.currentTarget.checked;
        chrome.storage.local.set({ status: e }),
          reloadTab([
            "*://*.pandabuy.com/*",
            "*://*.yupoo.com/*",
            "*://*.weidian.com/*",
            "*://weidian.com/*",
            "*://*.taobao.com/*",
            "*://*.1688.com/*",
            "*://*.tmall.com/*",
          ]),
          (o.style.maxHeight = e ? o.scrollHeight + "px" : "0px");
      }),
      chrome.storage.local.get(["status"], (e) => {
        (e = e?.status ?? !0),
          (t.checked = e),
          (o.style.maxHeight = e ? o.scrollHeight + "px" : "0px");
      }),
      new XMLHttpRequest());
  a.open("GET", chrome.runtime.getURL("currencies.json")),
    (a.onreadystatechange = function () {
      if (4 == this.readyState && 200 === this.status) {
        const e = JSON.parse(a.responseText),
          n = document.getElementById("convertTo");
        chrome.storage.local.get(["convertTo"], (o) => {
          e.forEach((e) => {
            var t = document.createElement("option");
            (t.value = e.name),
              (t.text = e.name + " - " + e.symbol),
              n.appendChild(t),
              (o?.convertTo !== e.name && (o?.convertTo || "USD" !== e.name)) ||
                (t.selected = "selected");
          });
        }),
          n.addEventListener("change", () => {
            chrome.storage.local.set({ convertTo: n.value }), reloadTab();
          });
      }
    }),
    a.send();
  for (const e of document.querySelectorAll("a"))
    e.addEventListener("click", (e) => {
      chrome.tabs.create({ url: e.target.getAttribute("href") });
    });
  let n = [];
  document.addEventListener("keydown", (e) => {
    n.push(e.key),
      n.forEach((e, t) => {
        switch (t) {
          case 0:
          case 1:
            "ArrowUp" !== e && (n = []);
            break;
          case 2:
          case 3:
            "ArrowDown" !== e && (n = []);
            break;
          case 4:
          case 6:
            "ArrowLeft" !== e && (n = []);
            break;
          case 5:
          case 7:
            "ArrowRight" !== e && (n = []);
            break;
          case 8:
            "b" !== e && (n = []);
            break;
          case 9:
            "a" !== e && (n = []);
        }
        9 == t &&
          10 == n.length &&
          ((n = []),
          chrome.storage.local.get(["popupDarkTheme"], (e) => {
            e = e?.popupDarkTheme ?? !1;
            e = document.createElement("div");
            (e.classList =
              "fixed bg-neutral-500 dark:bg-neutral-400 bg-opacity-75 h-screen z-50 w-full h-full top-0 left-0 flex flex-col justify-content-center items-center"),
              (e.innerHTML =
                '<img src="/src/Screamer.webp" class="h-full w-auto">'),
              (e.id = "screamer"),
              document.body.appendChild(e),
              setTimeout(() => {
                document.getElementById("screamer") &&
                  document.getElementById("screamer").remove();
              }, 1500);
          }));
      });
  });
});
